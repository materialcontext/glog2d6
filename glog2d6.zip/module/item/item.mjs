export class GLOG2D6Item extends Item {

  prepareData() {
    super.prepareData();
  }

  prepareBaseData() {
    // Items don't need much preparation for now
  }

  prepareDerivedData() {
    // Future: calculate derived values for items
  }
}
